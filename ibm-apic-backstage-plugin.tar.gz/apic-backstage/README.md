The APIC backend module for the catalog plugin. To provide federation between multiple APIC instances.

### Pre-requisites

* A working, scaffolded Backstage app, installed and configured - see <https://backstage.io/docs/getting-started/>
* A working PostgresSQL database hooked up to your Backstage install for pesistent data.

### Installing the plugin

1. Unpack zip archive in plugins directory

```bash
tar -xvf ibm-apic-backstage-plugin.tar.gz -C plugins
```

2. From backstage app base path

  ```bash
  yarn --cwd packages/backend add @internal/apic-backstage@^0.1.0
  ```

### Configuration the API Connect Plugin

1. For each APIC instance/cloud you wish to configure you need to add name, url, clientId, clientSecret, username, password for a provider organisation in a section at the end of app-config.yaml

 ```yaml
 ibm-apic:
     - name: apic-instance-1
       url: https://api.<instance1>.com/api
       clientId: '<instance1-clientID>'
       clientSecret: '<instance1-clientSecret>'
       username: '<instance1-porg-user>'
       password: '<instance1-porg-pwd>'
       # Optional: Change the schedule at which the instance is polled. Default is every 5 minutes
       schedule: '*/10 * * * *'
     - name: apic-instance-2
       url: https://api.<instance2>.com/api
       clientId: '<instance2-clientID>'
       clientSecret: '<instance2-clientSecret>'
       username: '<instance2-porg-user>'
       password: '<instance2-porg-pwd>'
 ```

The values for the url, clientId and clientSecret can be found by downloading the toolkit credentials (<https://www.ibm.com/docs/en/api-connect/10.0.x?topic=configuration-installing-toolkit#task_qsv_cgq_nt__download_creds>)

The url is the value for the "endpoint" for the "toolkit",  with the corresponding values for "client_id" mapping to "clientId", and "client_secret" mapping to "clientSecret".

For example the credentials.json for apic-instance-1 in the example above could be:

```json
{
  "cloud_id": "<instance1-cloudID>",
  "toolkit": {
    "endpoint": "https://api.<instance1>com/api",
    "client_id": "<instance1-clientID>",
    "client_secret": "<instance1-clientSecret>"
  },
  "consumer_toolkit": {
    ...
  },
  ...
}
```

**Note**: the credentials.json uses snake case, the app-config.yaml API Connect configuration uses camel case.

The username and password are for a provider organization member.  For this tech preview it is assumed that there is a single user who is a member of each provider organization to be added to the backstage instance - they should have viewer role for each provider organization at least.  This user can also be a member of more than one provider organization.

2. For your Backstage app, edit packages/backend/src/index.ts.  Add the following to the end of the file.

  ```javascript
  backend.add(import('@internal/apic-backstage'));
  ```

3. Start backstage app

```bash
yarn dev
```

#### References:

<https://backstage.io/docs/>

<https://www.ibm.com/docs/en/api-connect/10.0.x>

#### Known Limitations

* only tested with local user registry.
* do not use capitals or punctuation other than `-` for the name in the apic config.
* renaming or removing configuration currently leaves stale data in the database, this currently does not get removed.  The only way to clear this is to recreate the database and restart the Backstage application.
